"""The hidapi package (pip `hidapi`, module `hid`): the pad on Windows and macOS.

UNTESTED on Windows and macOS (CONTROLLER-PAD.md §8 marks both [guess]); it
has run only on Linux, where hidapi sits on hidraw too. What is assumed:

- The vendor interface is interface 0, as on Linux (input0). On macOS
  hidapi may report interface_number -1 for a device it reaches through
  IOHIDManager; then the usage page tells the two faces apart - the vendor
  interface is not the generic-desktop keyboard (usage page 1, usage 6).
- Writes carry the report id first (0: the AKP03E has no numbered reports),
  the same bytes the hidraw path writes. Windows insists the length is the
  output report length plus one, which the driver's framing already gives.
- macOS may ask for Input Monitoring permission the first time [guess].

hid is imported when a transport is opened, not at import time, so the core
library works without the package.
"""

from __future__ import annotations


def _hid():
    import hid  # noqa: PLC0415  (optional dependency: shack-pad[hid])
    return hid


def find(vendor: int, product: int, interface: int = 0) -> list[str]:
    """hidapi paths (opaque, per OS) of the vendor interface of each device."""
    try:
        hid = _hid()
    except ImportError:
        return []
    out = []
    for d in hid.enumerate(vendor, product):
        n = d.get("interface_number", -1)
        keyboard = d.get("usage_page") == 1 and d.get("usage") == 6
        if n == interface or (n == -1 and not keyboard):
            path = d.get("path")
            out.append(path.decode() if isinstance(path, bytes) else str(path))
    return out


class HidapiTransport:
    def __init__(self, path: str):
        hid = _hid()
        self.path = path
        self.dev = hid.device()
        self.dev.open_path(path.encode())

    def read(self, timeout: float) -> bytes | None:
        if self.dev is None:
            raise OSError("closed")
        try:
            data = self.dev.read(1024, max(1, int(timeout * 1000)))
        except (OSError, ValueError) as exc:     # hidapi raises IOError("read error") when unplugged
            raise OSError(str(exc)) from exc
        return bytes(data) if data else None

    def write(self, data: bytes) -> None:
        if self.dev is None:
            raise OSError("closed")
        try:
            n = self.dev.write(data)
        except (OSError, ValueError) as exc:
            raise OSError(str(exc)) from exc
        if n is not None and n < 0:
            raise OSError("write failed")

    def close(self) -> None:
        if self.dev is not None:
            try:
                self.dev.close()
            except Exception:
                pass
            self.dev = None
