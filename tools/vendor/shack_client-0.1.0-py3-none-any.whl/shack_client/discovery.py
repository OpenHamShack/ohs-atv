"""Finding controllers on the LAN (CONTROLLER-CONTRACT.md §2).

Two record types are browsed: `_openhamshack._tcp` (a controller, always
with TXT `platform=1`) and the legacy `_linkbox._tcp`, which is a Classic
0.9.x box when it has no `platform` key (shown as one qo100wb app, PIN
session on port 8080) and, with `platform=1`, PLATFORM-PLAN's draft name
for the same advert. When both resolve to one host, the
`_openhamshack` record wins.

The parsing and merging are pure functions, tested without a network.
Browsing needs python-zeroconf (`shack-client[discovery]`, LGPL-2.1); without
it `discover()` returns nothing and says why in `DiscoveryUnavailable`, and
a typed address is always the fallback (§2.2 step 4).
"""
from __future__ import annotations

from ._i18n import _

import time
from dataclasses import dataclass, field

from .transport import HttpTransport, Offline

SERVICE = "_openhamshack._tcp.local."
LEGACY = "_linkbox._tcp.local."


class DiscoveryUnavailable(Exception):
    pass


@dataclass
class Controller:
    name: str
    id: str                    # the advert's 8-hex `id`; the full controllerId comes from well_known()
    url: str
    kinds: list = field(default_factory=list)
    version: str = ""
    contract: str = ""
    classic: bool = False      # a Classic 0.9.x box, not a controller
    service: str = SERVICE
    address: str = ""
    port: int = 0


def _txt(props: dict) -> dict:
    out = {}
    for k, v in (props or {}).items():
        k = k.decode("ascii", "replace") if isinstance(k, bytes) else str(k)
        if isinstance(v, bytes):
            v = v.decode("ascii", "replace")
        out[k] = "" if v is None else str(v)
    return out


def parse_advert(service_type: str, instance: str, address: str, port: int, props: dict) -> Controller | None:
    """One resolved DNS-SD record as a Controller, or None if it is not
    ours. `instance` is the service instance name (the callsign)."""
    txt = _txt(props)
    st = service_type if service_type.endswith(".") else service_type + "."
    name = txt.get("name") or instance.split("." + st.split(".")[0])[0]
    if st.startswith("_openhamshack._tcp") or (st.startswith("_linkbox._tcp") and txt.get("platform") == "1"):
        if txt.get("platform") != "1":
            return None
        scheme_port = (f"https://{address}:{txt['https']}/" if txt.get("https") else f"http://{address}:{port}/")
        kinds = sorted(k for k in txt.get("kinds", "").split(",") if k)
        return Controller(name, txt.get("id", ""), scheme_port, kinds, txt.get("version", ""), txt.get("contract", ""),
                          False, SERVICE if st.startswith("_openhamshack") else LEGACY, address, port)
    if st.startswith("_linkbox._tcp"):
        # Classic box: REMOTE-API §1 TXT `name`, `version`, `port`.
        p = int(txt.get("port") or port or 8080)
        return Controller(name, "", f"http://{address}:{p}/", ["qo100wb"], txt.get("version", ""), "", True, LEGACY,
                          address, p)
    return None


def merge_adverts(found: list[Controller]) -> list[Controller]:
    """One entry per host: the `_openhamshack` record beats a `_linkbox`
    one with platform=1 for the same address and port; Classic boxes stay
    as they are (a Classic box and a controller are different things even
    on one host, since the controller's legacy listener is the WB app)."""
    best: dict[tuple, Controller] = {}
    for c in found:
        key = (c.address, c.port, c.classic)
        cur = best.get(key)
        if cur is None or (c.service == SERVICE and cur.service != SERVICE):
            best[key] = c
    return sorted(best.values(), key=lambda c: (c.name, c.url))


def well_known(base_url: str, transport=None) -> dict:
    """GET <base>.well-known/openhamshack, with every relative reference
    in it resolved against the base URL. Raises ValueError if the answer
    is not a controller this library speaks to.

    Resolved against the base, not against the document's own URL as §3
    literally says: by RFC 3986 "api/shack/token" against
    ".../.well-known/openhamshack" is ".../.well-known/api/shack/token",
    which is not where the contract means. The contract text is corrected
    to say so."""
    from .transport import join
    t = transport or HttpTransport(base_url, timeout=5.0)
    status, doc = t.request("GET", ".well-known/openhamshack")
    if status != 200 or "openhamshack" not in doc:
        raise ValueError(_("{address} is not an OpenHamShack controller").format(address=base_url))
    if doc["openhamshack"] != 1:
        raise ValueError(_("This controller is newer than this app: update the app to use it"))
    resolved = dict(doc)
    resolved["auth"] = {k: (join(base_url, v) if k in ("token", "pair") and isinstance(v, str) else v)
                        for k, v in (doc.get("auth") or {}).items()}
    if "base" in (doc.get("services") or {}):
        resolved["services"] = dict(doc["services"], base=join(base_url, doc["services"]["base"]))
    resolved["apps"] = [dict(a, base=join(base_url, a["base"]), **({"icon": join(base_url, a["icon"])} if a.get("icon")
                                                                    else {})) for a in doc.get("apps", [])]
    return resolved


def discover(timeout: float = 3.0) -> list[Controller]:
    """Browse both service types for `timeout` seconds."""
    try:
        from zeroconf import ServiceBrowser, Zeroconf
    except ImportError:
        raise DiscoveryUnavailable("Finding controllers on the network needs python-zeroconf "
                                   "(install shack-client[discovery]); type the controller's address instead") from None
    zc = Zeroconf()
    found: list[Controller] = []

    class Listener:
        def add_service(self, z, st, name):
            info = z.get_service_info(st, name, timeout=int(timeout * 1000))
            if info is None:
                return
            for addr in info.parsed_addresses():
                if ":" in addr:
                    continue              # IPv4 only (§2.1)
                c = parse_advert(st, name, addr, info.port, info.properties)
                if c is not None:
                    found.append(c)

        def update_service(self, z, st, name):
            self.add_service(z, st, name)

        def remove_service(self, z, st, name):
            pass

    try:
        ServiceBrowser(zc, [SERVICE, LEGACY], Listener())
        time.sleep(timeout)
    finally:
        zc.close()
    return merge_adverts(found)


__all__ = ["Controller", "DiscoveryUnavailable", "LEGACY", "Offline", "SERVICE", "discover", "merge_adverts",
           "parse_advert", "well_known"]
